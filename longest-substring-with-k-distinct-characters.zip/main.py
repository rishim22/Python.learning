a = "ecedf"
k = 2
left = 0
freq = {}
maxi = 0

for right in range(len(a)):
    freq[a[right]]=freq.get(a[right],0)+1
    
    while len(freq) > k:
        freq[a[left]]-=1
        if freq[a[left]]==0:
            del freq[a[left]]
            left+=1
        
    if len(freq) == k:
        maxi=max(maxi,right -left+1)
        
print(maxi)
    
    
    