"""Find most frequent word"""
ch="Find most frequent word"
freq={}
word=ch.split()
for words in word:
    freq[words]=freq.get(words,0)+1
print(freq)
     
        

