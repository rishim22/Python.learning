ch = "find most frequent word"
freq = {}

for c in ch:
    if c != " ":   # optional: ignore spaces
        freq[c] = freq.get(c, 0) + 1

print(freq)