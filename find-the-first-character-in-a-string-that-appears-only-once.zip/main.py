"""Find the first character in a string that appears only once
s = "aabbcdeff"
"""
s = "aabbcdeff"
freq={}

for ch in s:
    freq[ch]=freq.get(ch,0)+1
for ch in s:
    if freq[ch]==1:
        print(ch)
        break

