#armstrong No
#123=1^3+2^3+3^3=123 
def armstrongg(num):
    sum=num
    s=0
    a=len(str(num))
    while num!=0:
        d=num%10
        s=s+d**a
        num=num//10
    if s==sum:
        print("armstrong=",sum)
    else:
       print("not armstrong=",sum)
   
armstrongg(123)
    
    