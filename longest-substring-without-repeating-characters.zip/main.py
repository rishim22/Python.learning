"""a=abcdefsafeeb"""
a="bacdefsafeeb"
left=0
right=0
maxi=0
dicct={}
while right<(len(a)):
    if a[right] in dicct:
        left=max(left,dicct[a[right]]+1)
        
        
        
    maxi=max(maxi,right-left+1)
    dicct[a[right]]=right
    right+=1
print(maxi)
        
    
    
    
    
    

  